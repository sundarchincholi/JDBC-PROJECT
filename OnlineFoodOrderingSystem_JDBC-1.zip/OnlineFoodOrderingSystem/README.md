# Online Food Ordering System - JDBC

Technology:
- Java
- JDBC
- MySQL
- MySQL Connector/J

Modules:
1. Customer Registration
2. View Menu
3. Place Order
4. Order History
5. Bill Generation

JDBC Concepts:
- Master-detail relationship: orders -> order_items
- Transactions: placing an order and bill generation

## Database setup

1. Open MySQL Workbench.
2. Run `database/online_food_ordering.sql`.
3. Add MySQL Connector/J JAR to your Java project.
4. Open `src/com/foodordering/util/DBConnection.java`.
5. Change USER and PASSWORD to your MySQL credentials.
6. Run `Main.java`.

Default database:
`online_food_ordering_system`

Default MySQL connection:
`jdbc:mysql://localhost:3306/online_food_ordering_system?useSSL=false&serverTimezone=UTC`

## Project structure

src/
  com/foodordering/
    Main.java
    dao/
      CustomerDAO.java
      MenuDAO.java
      OrderDAO.java
    model/
      Customer.java
      MenuItem.java
      OrderItem.java
    service/
      FoodOrderService.java
    util/
      DBConnection.java

database/
  online_food_ordering.sql
