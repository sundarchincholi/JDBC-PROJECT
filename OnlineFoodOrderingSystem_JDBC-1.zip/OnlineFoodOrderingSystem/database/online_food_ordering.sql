CREATE DATABASE IF NOT EXISTS online_food_ordering_system;
USE online_food_ordering_system;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS menu;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL UNIQUE,
    email VARCHAR(100) UNIQUE,
    address VARCHAR(255) NOT NULL
);

CREATE TABLE menu (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    item_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    available BOOLEAN DEFAULT TRUE
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10,2) DEFAULT 0.00,
    status VARCHAR(30) DEFAULT 'PLACED',
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    item_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (item_id) REFERENCES menu(item_id)
);

INSERT INTO menu (item_name, category, price) VALUES
('Veg Burger', 'Fast Food', 120.00),
('Chicken Burger', 'Fast Food', 180.00),
('Margherita Pizza', 'Pizza', 250.00),
('Chicken Pizza', 'Pizza', 350.00),
('French Fries', 'Sides', 90.00),
('Veg Biryani', 'Main Course', 160.00),
('Chicken Biryani', 'Main Course', 220.00),
('Masala Dosa', 'South Indian', 80.00),
('Paneer Tikka', 'Starters', 200.00),
('Cold Coffee', 'Beverages', 100.00);

SELECT * FROM customers;
SELECT * FROM menu;
SELECT * FROM orders;
SELECT * FROM order_items;
