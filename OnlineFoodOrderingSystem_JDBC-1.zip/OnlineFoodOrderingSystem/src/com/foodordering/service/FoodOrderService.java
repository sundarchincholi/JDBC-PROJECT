package com.foodordering.service;

import com.foodordering.model.OrderItem;
import com.foodordering.util.DBConnection;
import java.sql.*;
import java.util.List;

public class FoodOrderService {

    public int placeOrder(int customerId, List<OrderItem> items) {
        if (items == null || items.isEmpty()) {
            System.out.println("Cart is empty.");
            return -1;
        }

        String insertOrder = "INSERT INTO orders(customer_id, total_amount, status) VALUES (?, 0, 'PLACED')";
        String getPrice = "SELECT price, available FROM menu WHERE item_id = ?";
        String insertItem = "INSERT INTO order_items(order_id, item_id, quantity, price) VALUES (?, ?, ?, ?)";
        String updateTotal = "UPDATE orders SET total_amount = ? WHERE order_id = ?";

        try (Connection con = DBConnection.getConnection()) {
            // Transaction starts
            con.setAutoCommit(false);

            try {
                int orderId;

                try (PreparedStatement ps = con.prepareStatement(
                        insertOrder, Statement.RETURN_GENERATED_KEYS)) {

                    ps.setInt(1, customerId);
                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (!rs.next()) {
                            throw new SQLException("Could not create order.");
                        }
                        orderId = rs.getInt(1);
                    }
                }

                double total = 0;

                try (PreparedStatement pricePs = con.prepareStatement(getPrice);
                     PreparedStatement itemPs = con.prepareStatement(insertItem)) {

                    for (OrderItem item : items) {
                        pricePs.setInt(1, item.getItemId());

                        double price;
                        boolean available;

                        try (ResultSet rs = pricePs.executeQuery()) {
                            if (!rs.next()) {
                                throw new SQLException("Menu item not found: " + item.getItemId());
                            }

                            price = rs.getDouble("price");
                            available = rs.getBoolean("available");
                        }

                        if (!available) {
                            throw new SQLException("Menu item is unavailable: " + item.getItemId());
                        }

                        if (item.getQuantity() <= 0) {
                            throw new SQLException("Quantity must be greater than zero.");
                        }

                        itemPs.setInt(1, orderId);
                        itemPs.setInt(2, item.getItemId());
                        itemPs.setInt(3, item.getQuantity());
                        itemPs.setDouble(4, price);
                        itemPs.executeUpdate();

                        total += price * item.getQuantity();
                    }
                }

                try (PreparedStatement ps = con.prepareStatement(updateTotal)) {
                    ps.setDouble(1, total);
                    ps.setInt(2, orderId);
                    ps.executeUpdate();
                }

                // Commit all master-detail changes together
                con.commit();

                System.out.printf("Order placed successfully! Order ID: %d, Total: Rs. %.2f%n",
                        orderId, total);

                return orderId;

            } catch (Exception e) {
                // Roll back if any step fails
                con.rollback();
                System.out.println("Order failed. Transaction rolled back.");
                System.out.println("Reason: " + e.getMessage());
                return -1;
            } finally {
                con.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
            return -1;
        }
    }
}
