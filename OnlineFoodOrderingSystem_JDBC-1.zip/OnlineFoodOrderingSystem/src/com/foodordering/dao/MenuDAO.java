package com.foodordering.dao;

import com.foodordering.model.MenuItem;
import com.foodordering.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MenuDAO {

    public List<MenuItem> getAvailableMenu() {
        List<MenuItem> menu = new ArrayList<>();
        String sql = "SELECT item_id, item_name, category, price, available FROM menu WHERE available = TRUE";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                menu.add(new MenuItem(
                        rs.getInt("item_id"),
                        rs.getString("item_name"),
                        rs.getString("category"),
                        rs.getDouble("price"),
                        rs.getBoolean("available")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Could not load menu: " + e.getMessage());
        }
        return menu;
    }
}
