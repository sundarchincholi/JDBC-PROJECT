package com.foodordering.dao;

import com.foodordering.util.DBConnection;
import java.sql.*;

public class OrderDAO {

    public void showOrderHistory(int customerId) {
        String sql = "SELECT order_id, order_date, total_amount, status " +
                     "FROM orders WHERE customer_id = ? ORDER BY order_date DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, customerId);

            try (ResultSet rs = ps.executeQuery()) {
                System.out.println("\n========== ORDER HISTORY ==========");
                boolean found = false;

                while (rs.next()) {
                    found = true;
                    System.out.printf(
                            "Order ID: %d | Date: %s | Total: Rs. %.2f | Status: %s%n",
                            rs.getInt("order_id"),
                            rs.getTimestamp("order_date"),
                            rs.getDouble("total_amount"),
                            rs.getString("status")
                    );
                }

                if (!found) {
                    System.out.println("No orders found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Could not load order history: " + e.getMessage());
        }
    }

    public void generateBill(int orderId) {
        String sql = "SELECT o.order_id, c.name, c.phone, o.order_date, " +
                     "m.item_name, oi.quantity, oi.price, " +
                     "(oi.quantity * oi.price) AS item_total, o.total_amount " +
                     "FROM orders o " +
                     "JOIN customers c ON o.customer_id = c.customer_id " +
                     "JOIN order_items oi ON o.order_id = oi.order_id " +
                     "JOIN menu m ON oi.item_id = m.item_id " +
                     "WHERE o.order_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, orderId);

            try (ResultSet rs = ps.executeQuery()) {
                boolean found = false;
                double total = 0;

                System.out.println("\n============== BILL ==============");

                while (rs.next()) {
                    if (!found) {
                        System.out.println("Order ID : " + rs.getInt("order_id"));
                        System.out.println("Customer : " + rs.getString("name"));
                        System.out.println("Phone    : " + rs.getString("phone"));
                        System.out.println("Date     : " + rs.getTimestamp("order_date"));
                        System.out.println("----------------------------------");
                        found = true;
                    }

                    double itemTotal = rs.getDouble("item_total");
                    total = rs.getDouble("total_amount");

                    System.out.printf("%-20s Qty: %-3d Price: Rs. %-8.2f Total: Rs. %.2f%n",
                            rs.getString("item_name"),
                            rs.getInt("quantity"),
                            rs.getDouble("price"),
                            itemTotal);
                }

                if (found) {
                    System.out.println("----------------------------------");
                    System.out.printf("GRAND TOTAL: Rs. %.2f%n", total);
                    System.out.println("==================================");
                } else {
                    System.out.println("Order not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Could not generate bill: " + e.getMessage());
        }
    }
}
