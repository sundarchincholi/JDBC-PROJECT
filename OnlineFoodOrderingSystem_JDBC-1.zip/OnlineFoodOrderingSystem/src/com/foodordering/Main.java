package com.foodordering;

import com.foodordering.dao.CustomerDAO;
import com.foodordering.dao.MenuDAO;
import com.foodordering.dao.OrderDAO;
import com.foodordering.model.Customer;
import com.foodordering.model.MenuItem;
import com.foodordering.model.OrderItem;
import com.foodordering.service.FoodOrderService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final CustomerDAO customerDAO = new CustomerDAO();
    private static final MenuDAO menuDAO = new MenuDAO();
    private static final OrderDAO orderDAO = new OrderDAO();
    private static final FoodOrderService orderService = new FoodOrderService();

    private static int loggedInCustomerId = -1;

    public static void main(String[] args) {

        while (true) {
            System.out.println("\n======================================");
            System.out.println("      ONLINE FOOD ORDERING SYSTEM");
            System.out.println("======================================");
            System.out.println("1. Customer Registration");
            System.out.println("2. View Menu");
            System.out.println("3. Place Order");
            System.out.println("4. Order History");
            System.out.println("5. Bill Generation");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");

            int choice = readInt();

            switch (choice) {
                case 1:
                    registerCustomer();
                    break;
                case 2:
                    viewMenu();
                    break;
                case 3:
                    placeOrder();
                    break;
                case 4:
                    showOrderHistory();
                    break;
                case 5:
                    generateBill();
                    break;
                case 6:
                    System.out.println("Thank you for using the system!");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void registerCustomer() {
        System.out.println("\n--- CUSTOMER REGISTRATION ---");

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Phone: ");
        String phone = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Address: ");
        String address = sc.nextLine();

        Customer customer = new Customer(name, phone, email, address);
        int id = customerDAO.registerCustomer(customer);

        if (id != -1) {
            loggedInCustomerId = id;
            System.out.println("Registration successful!");
            System.out.println("Customer ID: " + id);
            System.out.println("You are now the active customer.");
        }
    }

    private static void viewMenu() {
        System.out.println("\n================ MENU ================");

        List<MenuItem> menu = menuDAO.getAvailableMenu();

        System.out.printf("%-8s %-22s %-18s %-10s%n",
                "ID", "Food", "Category", "Price");

        System.out.println("----------------------------------------------------------");

        for (MenuItem item : menu) {
            System.out.printf("%-8d %-22s %-18s Rs. %.2f%n",
                    item.getItemId(),
                    item.getItemName(),
                    item.getCategory(),
                    item.getPrice());
        }
    }

    private static void placeOrder() {
        if (loggedInCustomerId == -1) {
            System.out.println("Please register a customer first.");
            return;
        }

        viewMenu();

        List<OrderItem> cart = new ArrayList<>();

        System.out.println("\n--- ADD ITEMS TO CART ---");
        System.out.println("Enter 0 as Item ID to finish.");

        while (true) {
            System.out.print("Enter Item ID: ");
            int itemId = readInt();

            if (itemId == 0) {
                break;
            }

            System.out.print("Enter Quantity: ");
            int quantity = readInt();

            cart.add(new OrderItem(itemId, quantity));
            System.out.println("Item added to cart.");
        }

        if (!cart.isEmpty()) {
            orderService.placeOrder(loggedInCustomerId, cart);
        } else {
            System.out.println("No items selected.");
        }
    }

    private static void showOrderHistory() {
        if (loggedInCustomerId == -1) {
            System.out.println("Please register a customer first.");
            return;
        }

        orderDAO.showOrderHistory(loggedInCustomerId);
    }

    private static void generateBill() {
        System.out.print("Enter Order ID: ");
        int orderId = readInt();
        orderDAO.generateBill(orderId);
    }

    private static int readInt() {
        while (true) {
            try {
                int value = Integer.parseInt(sc.nextLine());
                return value;
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}
