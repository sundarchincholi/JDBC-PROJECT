# Online Examination System - JDBC Project

A simple online examination web application using **Java 17, JSP/Servlets, JDBC, MySQL and Apache Tomcat 10**.

## Features
- Student/Admin login
- Exam listing
- Multiple-choice questions
- Exam submission
- Automatic score calculation
- JDBC DAO layer
- MySQL database schema + sample data
- Responsive CSS

## Requirements
- JDK 17+
- Maven 3.8+
- MySQL 8+
- Apache Tomcat 10+

## Database setup
1. Start MySQL.
2. Open `database/schema.sql` in MySQL Workbench or the MySQL client.
3. Execute it.
4. Open `src/main/java/com/exam/util/DBConnection.java` and change `USER` and `PASSWORD` if your MySQL credentials differ.

Default database credentials expected by the project:
- username: `root`
- password: `root`

## Build
From the project directory:

```bash
mvn clean package
```

The WAR will be created at:

`target/online-examination-system.war`

## Run on Tomcat
Copy the WAR into Tomcat's `webapps` folder and start Tomcat.

Open:

`http://localhost:8080/online-examination-system/`

## Demo accounts
Student: `student@example.com` / `student123`

Admin: `admin@example.com` / `admin123`

## Notes
This is an educational starter project. Passwords are stored as plain text for simplicity; for production, use BCrypt/Argon2 hashing, connection pooling, CSRF protection, role-based admin pages, and stronger session/security controls.
