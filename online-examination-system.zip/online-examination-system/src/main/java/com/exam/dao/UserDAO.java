package com.exam.dao;
import com.exam.model.User; import com.exam.util.DBConnection; import java.sql.*;
public class UserDAO { public User login(String email,String password) throws SQLException { String sql="SELECT * FROM users WHERE email=? AND password=?"; try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setString(1,email);p.setString(2,password);try(ResultSet r=p.executeQuery()){if(r.next()) return new User(r.getInt("id"),r.getString("name"),r.getString("email"),r.getString("password"),r.getString("role"));}} return null;}}
