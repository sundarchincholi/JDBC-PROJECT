package com.exam.model;
public class Exam { private int id,durationMinutes; private String title,description;
 public int getId(){return id;} public void setId(int v){id=v;} public int getDurationMinutes(){return durationMinutes;} public void setDurationMinutes(int v){durationMinutes=v;} public String getTitle(){return title;} public void setTitle(String v){title=v;} public String getDescription(){return description;} public void setDescription(String v){description=v;}
}
