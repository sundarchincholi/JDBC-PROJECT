CREATE DATABASE IF NOT EXISTS online_exam;
USE online_exam;

DROP TABLE IF EXISTS answers;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS exams;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL,
  role ENUM('STUDENT','ADMIN') NOT NULL DEFAULT 'STUDENT'
);

CREATE TABLE exams (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  duration_minutes INT NOT NULL DEFAULT 30,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE questions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  exam_id INT NOT NULL,
  question_text TEXT NOT NULL,
  option_a VARCHAR(500) NOT NULL,
  option_b VARCHAR(500) NOT NULL,
  option_c VARCHAR(500) NOT NULL,
  option_d VARCHAR(500) NOT NULL,
  correct_option CHAR(1) NOT NULL,
  FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE
);

CREATE TABLE answers (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  exam_id INT NOT NULL,
  question_id INT NOT NULL,
  selected_option CHAR(1),
  is_correct BOOLEAN DEFAULT FALSE,
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

INSERT INTO users(name,email,password,role) VALUES
('Administrator','admin@example.com','admin123','ADMIN'),
('Demo Student','student@example.com','student123','STUDENT');

INSERT INTO exams(title,description,duration_minutes) VALUES
('Java Basics','Basic Java programming multiple-choice examination',20),
('Database & JDBC','SQL and JDBC fundamentals',20);

INSERT INTO questions(exam_id,question_text,option_a,option_b,option_c,option_d,correct_option) VALUES
(1,'Which keyword is used to inherit a class in Java?','implements','extends','inherits','super','B'),
(1,'Which method is the entry point of a Java application?','start()','run()','main()','init()','C'),
(1,'Which collection does not allow duplicate elements?','List','Set','ArrayList','Vector','B'),
(1,'Which type stores true or false?','boolean','bool','bit','logical','A'),
(2,'Which JDBC interface is commonly used to execute SQL statements?','ResultSet','Connection','Statement','Driver','C'),
(2,'Which JDBC object represents a database connection?','Connection','Session','Database','Connector','A'),
(2,'Which SQL command reads rows from a table?','INSERT','SELECT','UPDATE','DELETE','B'),
(2,'Which interface is preferred for parameterized SQL?','PreparedStatement','Callable','ResultSet','DatabaseMetaData','A');
