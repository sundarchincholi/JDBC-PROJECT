public class Employee {
    private int employeeId;
    private String name;
    private String department;
    private String email;
    private String phone;
    private double basicSalary;

    public Employee(int employeeId, String name, String department,
                    String email, String phone, double basicSalary) {
        this.employeeId = employeeId;
        this.name = name;
        this.department = department;
        this.email = email;
        this.phone = phone;
        this.basicSalary = basicSalary;
    }

    public int getEmployeeId() { return employeeId; }
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public double getBasicSalary() { return basicSalary; }

    @Override
    public String toString() {
        return employeeId + " | " + name + " | " + department +
               " | " + email + " | Basic: " + basicSalary;
    }
}
