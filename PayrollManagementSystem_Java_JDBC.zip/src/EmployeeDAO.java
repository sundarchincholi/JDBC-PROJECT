import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    public boolean addEmployee(String name, String department, String email,
                               String phone, double basicSalary) {
        String sql = "INSERT INTO employees(name,department,email,phone,basic_salary) " +
                     "VALUES(?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, department);
            ps.setString(3, email);
            ps.setString(4, phone);
            ps.setDouble(5, basicSalary);
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Add employee error: " + e.getMessage());
            return false;
        }
    }

    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();

        String sql = "SELECT employee_id,name,department,email,phone,basic_salary " +
                     "FROM employees ORDER BY employee_id";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                employees.add(new Employee(
                    rs.getInt("employee_id"),
                    rs.getString("name"),
                    rs.getString("department"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getDouble("basic_salary")
                ));
            }

        } catch (SQLException e) {
            System.out.println("Employee query error: " + e.getMessage());
        }

        return employees;
    }

    public boolean updateEmployee(int id, String name, String department,
                                  String email, String phone, double basicSalary) {
        String sql = "UPDATE employees SET name=?,department=?,email=?,phone=?," +
                     "basic_salary=? WHERE employee_id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, department);
            ps.setString(3, email);
            ps.setString(4, phone);
            ps.setDouble(5, basicSalary);
            ps.setInt(6, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Update employee error: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteEmployee(int id) {
        String sql = "DELETE FROM employees WHERE employee_id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Delete employee error: " + e.getMessage());
            return false;
        }
    }
}
