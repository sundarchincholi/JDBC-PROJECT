import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);

    private static final EmployeeDAO employeeDAO = new EmployeeDAO();
    private static final SalaryDAO salaryDAO = new SalaryDAO();
    private static final PayrollDAO payrollDAO = new PayrollDAO();

    public static void main(String[] args) {
        System.out.println("==============================================");
        System.out.println("          PAYROLL MANAGEMENT SYSTEM");
        System.out.println("             CORE JAVA + JDBC");
        System.out.println("==============================================");

        while (true) {
            System.out.println("\n1. Employee Management");
            System.out.println("2. Salary Management");
            System.out.println("3. Calculate Payroll");
            System.out.println("4. Batch Payroll Processing");
            System.out.println("5. Generate/View Payslip");
            System.out.println("6. Payroll Statistics");
            System.out.println("7. View Payroll");
            System.out.println("8. Exit");
            System.out.print("Enter choice: ");

            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> employeeMenu();
                case "2" -> salaryMenu();
                case "3" -> calculatePayroll();
                case "4" -> batchPayroll();
                case "5" -> payslip();
                case "6" -> payrollDAO.showPayrollStatistics();
                case "7" -> payrollDAO.showAllPayroll();
                case "8" -> {
                    System.out.println("Application closed.");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void employeeMenu() {
        while (true) {
            System.out.println("\n--- EMPLOYEE MANAGEMENT ---");
            System.out.println("1. Add Employee");
            System.out.println("2. View Employees");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Back");
            System.out.print("Choice: ");

            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> addEmployee();
                case "2" -> showEmployees();
                case "3" -> updateEmployee();
                case "4" -> deleteEmployee();
                case "5" -> { return; }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void addEmployee() {
        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Department: ");
        String department = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Phone: ");
        String phone = sc.nextLine();

        System.out.print("Basic Salary: ");
        double basic = readDouble();

        if (employeeDAO.addEmployee(name, department, email, phone, basic)) {
            System.out.println("Employee added.");
        }
    }

    private static void showEmployees() {
        List<Employee> employees = employeeDAO.getAllEmployees();

        System.out.println("\n--- EMPLOYEES ---");
        for (Employee e : employees) {
            System.out.println(e);
        }
    }

    private static void updateEmployee() {
        showEmployees();

        System.out.print("Employee ID: ");
        int id = readInt();

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Department: ");
        String department = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Phone: ");
        String phone = sc.nextLine();

        System.out.print("Basic Salary: ");
        double basic = readDouble();

        if (employeeDAO.updateEmployee(id, name, department, email, phone, basic)) {
            System.out.println("Employee updated.");
        } else {
            System.out.println("Employee not found.");
        }
    }

    private static void deleteEmployee() {
        showEmployees();

        System.out.print("Employee ID: ");
        int id = readInt();

        if (employeeDAO.deleteEmployee(id)) {
            System.out.println("Employee deleted.");
        } else {
            System.out.println("Employee not found.");
        }
    }

    private static void salaryMenu() {
        while (true) {
            System.out.println("\n--- SALARY MANAGEMENT ---");
            System.out.println("1. Add Salary Structure");
            System.out.println("2. View Salary Structures");
            System.out.println("3. Back");
            System.out.print("Choice: ");

            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> addSalary();
                case "2" -> salaryDAO.showSalaries();
                case "3" -> { return; }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void addSalary() {
        showEmployees();

        System.out.print("Employee ID: ");
        int employeeId = readInt();

        System.out.print("Basic Salary: ");
        double basic = readDouble();

        System.out.print("HRA: ");
        double hra = readDouble();

        System.out.print("DA: ");
        double da = readDouble();

        System.out.print("Allowance: ");
        double allowance = readDouble();

        if (salaryDAO.addSalary(employeeId, basic, hra, da, allowance)) {
            System.out.println("Salary structure added.");
        }
    }

    private static void calculatePayroll() {
        salaryDAO.showSalaries();

        System.out.print("Employee ID: ");
        int employeeId = readInt();

        System.out.print("Salary ID: ");
        int salaryId = readInt();

        System.out.print("Tax Rate (%): ");
        double taxRate = readDouble();

        System.out.print("Other Deduction: ");
        double other = readDouble();

        payrollDAO.calculatePayroll(employeeId, salaryId, taxRate, other);
    }

    private static void batchPayroll() {
        System.out.println("\n--- BATCH PAYROLL PROCESSING ---");
        System.out.print("Tax Rate (%): ");
        double taxRate = readDouble();

        System.out.print("Other Deduction per employee: ");
        double other = readDouble();

        payrollDAO.batchGeneratePayroll(taxRate, other);
    }

    private static void payslip() {
        showEmployees();

        System.out.print("Employee ID: ");
        int id = readInt();

        payrollDAO.showPayslip(id);
    }

    private static int readInt() {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Enter a valid integer: ");
            }
        }
    }

    private static double readDouble() {
        while (true) {
            try {
                return Double.parseDouble(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Enter a valid number: ");
            }
        }
    }
}
