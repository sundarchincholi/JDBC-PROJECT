import java.sql.*;

public class PayrollDAO {

    public void calculatePayroll(int employeeId, int salaryId, double taxRate,
                                 double otherDeduction) {

        String salarySql = "SELECT basic_salary,hra,da,allowance " +
                           "FROM salaries WHERE salary_id=? AND employee_id=?";

        String payrollSql = "INSERT INTO payroll(employee_id,salary_id,gross_salary," +
                            "tax_deduction,other_deduction,net_salary,pay_month) " +
                            "VALUES(?,?,?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            double basic;
            double hra;
            double da;
            double allowance;

            try (PreparedStatement ps = con.prepareStatement(salarySql)) {
                ps.setInt(1, salaryId);
                ps.setInt(2, employeeId);

                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        System.out.println("Salary record not found.");
                        con.rollback();
                        return;
                    }

                    basic = rs.getDouble("basic_salary");
                    hra = rs.getDouble("hra");
                    da = rs.getDouble("da");
                    allowance = rs.getDouble("allowance");
                }
            }

            double gross = basic + hra + da + allowance;
            double tax = gross * taxRate / 100.0;
            double net = gross - tax - otherDeduction;

            try (PreparedStatement ps = con.prepareStatement(payrollSql)) {
                ps.setInt(1, employeeId);
                ps.setInt(2, salaryId);
                ps.setDouble(3, gross);
                ps.setDouble(4, tax);
                ps.setDouble(5, otherDeduction);
                ps.setDouble(6, net);
                ps.setDate(7, new java.sql.Date(System.currentTimeMillis()));
                ps.executeUpdate();
            }

            con.commit();

            System.out.println("\nPayroll generated successfully.");
            System.out.printf("Gross Salary: %.2f%n", gross);
            System.out.printf("Tax Deduction: %.2f%n", tax);
            System.out.printf("Other Deduction: %.2f%n", otherDeduction);
            System.out.printf("Net Salary: %.2f%n", net);

        } catch (SQLException e) {
            System.out.println("Payroll calculation error: " + e.getMessage());
        }
    }

    // Batch Processing: generate payroll for multiple employees.
    public void batchGeneratePayroll(double taxRate, double otherDeduction) {
        String salarySql = "SELECT salary_id,employee_id,basic_salary,hra,da,allowance " +
                           "FROM salaries";

        String insertSql = "INSERT INTO payroll(employee_id,salary_id,gross_salary," +
                           "tax_deduction,other_deduction,net_salary,pay_month) " +
                           "VALUES(?,?,?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement select = con.prepareStatement(salarySql);
             PreparedStatement insert = con.prepareStatement(insertSql)) {

            con.setAutoCommit(false);

            try (ResultSet rs = select.executeQuery()) {
                while (rs.next()) {
                    int salaryId = rs.getInt("salary_id");
                    int employeeId = rs.getInt("employee_id");

                    double basic = rs.getDouble("basic_salary");
                    double hra = rs.getDouble("hra");
                    double da = rs.getDouble("da");
                    double allowance = rs.getDouble("allowance");

                    double gross = basic + hra + da + allowance;
                    double tax = gross * taxRate / 100.0;
                    double net = gross - tax - otherDeduction;

                    insert.setInt(1, employeeId);
                    insert.setInt(2, salaryId);
                    insert.setDouble(3, gross);
                    insert.setDouble(4, tax);
                    insert.setDouble(5, otherDeduction);
                    insert.setDouble(6, net);
                    insert.setDate(7, new java.sql.Date(System.currentTimeMillis()));

                    insert.addBatch();
                }
            }

            int[] result = insert.executeBatch();
            con.commit();

            System.out.println("Batch payroll completed.");
            System.out.println("Records processed: " + result.length);

        } catch (SQLException e) {
            System.out.println("Batch processing error: " + e.getMessage());
        }
    }

    public void showPayslip(int employeeId) {
        String sql = "SELECT e.employee_id,e.name,e.department,e.email," +
                     "p.pay_month,p.gross_salary,p.tax_deduction," +
                     "p.other_deduction,p.net_salary " +
                     "FROM payroll p " +
                     "JOIN employees e ON p.employee_id=e.employee_id " +
                     "WHERE p.employee_id=? ORDER BY p.payroll_id DESC LIMIT 1";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, employeeId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("\n======================================");
                    System.out.println("              PAYSLIP");
                    System.out.println("======================================");
                    System.out.println("Employee ID : " + rs.getInt("employee_id"));
                    System.out.println("Name        : " + rs.getString("name"));
                    System.out.println("Department  : " + rs.getString("department"));
                    System.out.println("Email       : " + rs.getString("email"));
                    System.out.println("Pay Month   : " + rs.getDate("pay_month"));
                    System.out.printf("Gross Salary: %.2f%n", rs.getDouble("gross_salary"));
                    System.out.printf("Tax         : %.2f%n", rs.getDouble("tax_deduction"));
                    System.out.printf("Other Ded.  : %.2f%n", rs.getDouble("other_deduction"));
                    System.out.printf("Net Salary  : %.2f%n", rs.getDouble("net_salary"));
                    System.out.println("======================================");
                } else {
                    System.out.println("No payroll found.");
                }
            }

        } catch (SQLException e) {
            System.out.println("Payslip error: " + e.getMessage());
        }
    }

    // Aggregate functions.
    public void showPayrollStatistics() {
        String sql = "SELECT COUNT(*) AS employees_paid, " +
                     "SUM(gross_salary) AS total_gross, " +
                     "SUM(tax_deduction) AS total_tax, " +
                     "AVG(net_salary) AS average_net, " +
                     "MAX(net_salary) AS highest_net " +
                     "FROM payroll";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                System.out.println("\n--- PAYROLL STATISTICS ---");
                System.out.println("Employees Paid: " + rs.getInt("employees_paid"));
                System.out.printf("Total Gross: %.2f%n", rs.getDouble("total_gross"));
                System.out.printf("Total Tax: %.2f%n", rs.getDouble("total_tax"));
                System.out.printf("Average Net: %.2f%n", rs.getDouble("average_net"));
                System.out.printf("Highest Net: %.2f%n", rs.getDouble("highest_net"));
            }

        } catch (SQLException e) {
            System.out.println("Statistics error: " + e.getMessage());
        }
    }

    public void showAllPayroll() {
        String sql = "SELECT e.name,p.pay_month,p.gross_salary,p.tax_deduction," +
                     "p.other_deduction,p.net_salary " +
                     "FROM payroll p JOIN employees e ON p.employee_id=e.employee_id " +
                     "ORDER BY p.payroll_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("\n--- ALL PAYROLL ---");
            while (rs.next()) {
                System.out.printf("%s | %s | Gross %.2f | Tax %.2f | Net %.2f%n",
                    rs.getString("name"),
                    rs.getDate("pay_month"),
                    rs.getDouble("gross_salary"),
                    rs.getDouble("tax_deduction"),
                    rs.getDouble("net_salary"));
            }

        } catch (SQLException e) {
            System.out.println("Payroll list error: " + e.getMessage());
        }
    }
}
