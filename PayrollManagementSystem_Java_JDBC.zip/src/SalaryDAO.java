import java.sql.*;

public class SalaryDAO {

    public boolean addSalary(int employeeId, double basic, double hra,
                             double da, double allowance) {

        String sql = "INSERT INTO salaries(employee_id,basic_salary,hra,da,allowance) " +
                     "VALUES(?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, employeeId);
            ps.setDouble(2, basic);
            ps.setDouble(3, hra);
            ps.setDouble(4, da);
            ps.setDouble(5, allowance);
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Salary error: " + e.getMessage());
            return false;
        }
    }

    public void showSalaries() {
        String sql = "SELECT s.salary_id,e.name,s.basic_salary,s.hra,s.da,s.allowance " +
                     "FROM salaries s JOIN employees e ON s.employee_id=e.employee_id " +
                     "ORDER BY s.salary_id";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("\n--- SALARY STRUCTURE ---");
            while (rs.next()) {
                System.out.printf("%d | %s | Basic %.2f | HRA %.2f | DA %.2f | Allowance %.2f%n",
                    rs.getInt("salary_id"),
                    rs.getString("name"),
                    rs.getDouble("basic_salary"),
                    rs.getDouble("hra"),
                    rs.getDouble("da"),
                    rs.getDouble("allowance"));
            }

        } catch (SQLException e) {
            System.out.println("Salary list error: " + e.getMessage());
        }
    }
}
