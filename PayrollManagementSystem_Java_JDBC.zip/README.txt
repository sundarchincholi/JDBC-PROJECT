PAYROLL MANAGEMENT SYSTEM
CORE JAVA + JDBC + MYSQL
=========================

Scenario:
HR calculates employee salaries every month.

Modules:
1. Employee Management
2. Salary Calculation
3. Payslip Generation
4. Tax Deduction

Tables:
employees
salaries
payroll

JDBC Concepts:
- CRUD
- PreparedStatement
- ResultSet
- Aggregate Functions: COUNT, SUM, AVG, MAX
- Batch Processing using addBatch() and executeBatch()
- Transactions

NO Maven
NO JSP
NO Servlet
NO Framework

Requirements:
- JDK 17+
- MySQL 8+
- MySQL Connector/J

SETUP
-----
1. Run sql/payroll.sql in MySQL Workbench.
2. Open src/DBConnection.java.
3. Change MySQL username/password.
4. Download MySQL Connector/J and put the JAR in lib/.

WINDOWS
-------
Compile:
javac -cp "lib/mysql-connector-j-*.jar" -d out src/*.java

Run:
java -cp "out;lib/mysql-connector-j-*.jar" Main

LINUX/MAC
---------
Compile:
javac -cp "lib/mysql-connector-j-*.jar" -d out src/*.java

Run:
java -cp "out:lib/mysql-connector-j-*.jar" Main

Payroll calculation:
Gross Salary = Basic + HRA + DA + Allowance
Tax = Gross Salary * tax rate / 100
Net Salary = Gross Salary - Tax - Other Deductions

Demo employees are inserted by the SQL script.

IMPORTANT:
MySQL Connector/J is a third-party library and is not bundled.
Download the JAR and copy it into the lib folder.
