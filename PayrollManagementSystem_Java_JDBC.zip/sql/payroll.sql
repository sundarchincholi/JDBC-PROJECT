CREATE DATABASE IF NOT EXISTS payroll_management;
USE payroll_management;

DROP TABLE IF EXISTS payroll;
DROP TABLE IF EXISTS salaries;
DROP TABLE IF EXISTS employees;

CREATE TABLE employees (
    employee_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    phone VARCHAR(20),
    basic_salary DECIMAL(12,2) NOT NULL
);

CREATE TABLE salaries (
    salary_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    basic_salary DECIMAL(12,2) NOT NULL,
    hra DECIMAL(12,2) DEFAULT 0,
    da DECIMAL(12,2) DEFAULT 0,
    allowance DECIMAL(12,2) DEFAULT 0,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE
);

CREATE TABLE payroll (
    payroll_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    salary_id INT NOT NULL,
    gross_salary DECIMAL(12,2) NOT NULL,
    tax_deduction DECIMAL(12,2) NOT NULL,
    other_deduction DECIMAL(12,2) DEFAULT 0,
    net_salary DECIMAL(12,2) NOT NULL,
    pay_month DATE NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    FOREIGN KEY (salary_id) REFERENCES salaries(salary_id)
);

INSERT INTO employees(name,department,email,phone,basic_salary) VALUES
('Rahul Sharma','IT','rahul@example.com','9876543210',40000),
('Priya Singh','HR','priya@example.com','9876543211',45000),
('Amit Kumar','Finance','amit@example.com','9876543212',50000);

INSERT INTO salaries(employee_id,basic_salary,hra,da,allowance) VALUES
(1,40000,8000,4000,3000),
(2,45000,9000,4500,3500),
(3,50000,10000,5000,4000);

-- CRUD examples:
-- INSERT INTO employees(...) VALUES(...);
-- SELECT * FROM employees;
-- UPDATE employees SET department=? WHERE employee_id=?;
-- DELETE FROM employees WHERE employee_id=?;

-- Aggregate examples:
-- SELECT COUNT(*) FROM payroll;
-- SELECT SUM(gross_salary) FROM payroll;
-- SELECT AVG(net_salary) FROM payroll;
-- SELECT MAX(net_salary) FROM payroll;

-- Join example:
-- SELECT e.name, e.department, p.gross_salary, p.tax_deduction, p.net_salary
-- FROM payroll p
-- JOIN employees e ON p.employee_id=e.employee_id;
